                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2073174
Geeetech i3 pro b e3d bowden mount with radial fan by ejalal is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

This is a combination from @FernandoGarcia and @Tech2C E3D v6 mounting bracket designs.

All credit goes to them for their great designs.

Be careful, you will lose about 10mm in the Y axis direction due to the fan duct being placed at the back of the E3D mounting hole. I'll move it in a future design to the the front or right side.

Make sure that your x carriage top screw is flush with the surface, you can add a spacer like on picture number 2 if your screw is too long, otherwise it will obstruct the radial fan.

TODO:
Done; The mounting clamp holes to be resized from m4 to m3
Reside the square nut holes down so they can match the M3 square nuts provided in the Geeetech kit
Move the fan mount and duct to the front or right side

# How I Designed This

I imported both designs in 123D Design and converted them to solid, then I cut the mounting plate from @FernandoGarcia's design and placed it in the @Tech2C design after I cut and removed it's mounting plate.

Then I resized the mounting holes from m4 to m3

Then I modified @Tech2C fan duct design to move the mounting holes a few mm to the top so they can match the new ones I created in the new mounting plate.